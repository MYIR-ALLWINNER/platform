

#ifndef __legacy_egl_h_
#define __legacy_egl_h_

#include <EGL/egl.h>
#include <GLES/gl.h>

#endif /* __legacy_egl_h_ */
